<?php
// Include database configuration
include_once 'config.php';

// Function to get paginated user records
function getPaginatedUsers($page, $perPage) {
    global $conn;

    $offset = ($page - 1) * $perPage;
    $sql = "SELECT * FROM members LIMIT $perPage OFFSET $offset";
    $result = $conn->query($sql);

    $users = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }

    return $users;
}

// Function to get total number of users
function getTotalUsers() {
    global $conn;

    $sql = "SELECT COUNT(*) as count FROM members";
    $result = $conn->query($sql);

    $totalUsers = 0;
    if ($result->num_rows > 0) {
        $totalUsers = $result->fetch_assoc()['count'];
    }

    return $totalUsers;
}
?>
