<?php
include_once 'db_functions.php';

$perPage = 10; // Number of records per page
$page = isset($_GET['page']) ? $_GET['page'] : 1; // Get current page number from URL parameter, default to 1 if not set

// Get paginated user records
$users = getPaginatedUsers($page, $perPage);

// Get total number of users
$totalUsers = getTotalUsers();

// Calculate total pages
$totalPages = ceil($totalUsers / $perPage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagination Example</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>User Records</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
        </tr>
        <?php foreach ($users as $user) : ?>
            <tr>
                <td><?php echo $user['id']; ?></td>
                <td><?php echo $user['name']; ?></td>
                <td><?php echo $user['email']; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
            <a href="index.php?page=<?php echo $i; ?>" <?php echo ($page == $i) ? 'class="active"' : ''; ?>><?php echo $i; ?></a>
        <?php endfor; ?>
    </div>
</body>
</html>
